import java.util.ArrayList;
import java.util.Scanner;

public class Main {

	Scanner scan = new Scanner(System.in);
	
	ArrayList<String> idArr = new ArrayList<String>();
	ArrayList<String> namaArr = new ArrayList<String>();
	ArrayList<String> jenisKelaminArr = new ArrayList<String>();
	ArrayList<String> jabatanArr = new ArrayList<String>();
	ArrayList<Integer> gajiArr = new ArrayList<>();
	
	public Main() {
		menu();
	}
	
	void menu() {
		int menu = 0;
		while (menu>=1 || menu<=4) {
		System.out.println("");
		System.out.println("PT. Mentol");
		System.out.println("1. Insert data karyawan");
		System.out.println("2. View data karyawan");
		System.out.println("3. Update data karyawan");
		System.out.println("4. Delete data karyawan");
		System.out.print(">>");
		
		try {
			menu = scan.nextInt();
			scan.nextLine();
		} catch (Exception e) {
			System.out.println("Input harus berupa angka!");
			System.out.println("");
			scan.nextLine();
			menu();	
		}	
		
		
		switch (menu) {
		case 1:
			
			String nama=null, jenisKelamin=null;
			String jabatan=null;
			int gaji = 0;
			
			do {
				System.out.print("Input nama karyawan [>= 3]: ");
				nama = scan.nextLine();
			} while(!(nama.length()>=3)&&nama.matches("^[a-zA-Z]*$"));
			
			do {
				System.out.print("Input jenis kelamin [Laki-laki] | Perempuan] (Case Sensitive): ");
				jenisKelamin = scan.nextLine();
			} while(!(jenisKelamin.equals("Laki-laki")||jenisKelamin.equals("Perempuan")));
		
			do {
				System.out.print("Input jabatan [Manager | Supervisor | Admin] (Case Sensitive): ");
				jabatan = scan.nextLine();
			} while(!jabatan.equals("Manager")&&!jabatan.equals("Supervisor")&&!jabatan.equals("Admin"));
			
			String id = "";
			int random1;
			
			for(int i=0; i<2; i++) {
				random1 = (int)(Math.random()*(90-65+1)+65);
				id+= String.valueOf((char) random1);
			}
			
			id+= '-';
			
			for(int i=0; i<4; i++) {
				random1 = (int)(Math.random()*10);
				id+= random1;
			}
			
			System.out.println("Berhasil menambahkan karyawan dengan id " + id);
			
			if(jabatan.equals("Manager")) {
				gaji = 8000000;
			} else if(jabatan.equals("Supervisor")) {
				gaji = 6000000;
			} else if(jabatan.equals("Admin")) {
				gaji = 4000000;
			}

			idArr.add(id);
			namaArr.add(nama);
			jenisKelaminArr.add(jenisKelamin);
			jabatanArr.add(jabatan);
			gajiArr.add(gaji);

			break;
			
		case 2:
			
			if(namaArr.size() == 0) {
				System.out.println("Tidak ada data karyawan!");
				menu();
			}
			
			else {
				System.out.println("|----|----------------|-------------------------|---------------|----------------|---------------|");
				System.out.println("|No  |Kode Karyawan   |Nama Karyawan            |Jenis Kelamin  |Jabatan         |Gaji Karyawan  |");
				System.out.println("|----|----------------|-------------------------|---------------|----------------|---------------|");
			for (int i = 0; i < namaArr.size(); i++) {	
				System.out.print("|   " +(i+1));
				System.out.print("|         " +idArr.get(i));
				System.out.print("|                   " +namaArr.get(i));
				System.out.print("|        " +jenisKelaminArr.get(i));
				System.out.print("|      " +jabatanArr.get(i));
				System.out.print("|      "+gajiArr.get(i));
				System.out.println("|");

			}
			
			break;
			}
			
		case 3:
			
			if(namaArr.size() == 0) {
				System.out.println("Tidak ada data karyawan!");
				menu();
			}
			
			else {
				System.out.println("|----|----------------|-------------------------|---------------|----------------|---------------|");
				System.out.println("|No  |Kode Karyawan   |Nama Karyawan            |Jenis Kelamin  |Jabatan         |Gaji Karyawan  |");
				System.out.println("|----|----------------|-------------------------|---------------|----------------|---------------|");
			for (int i = 0; i < namaArr.size(); i++) {	
				System.out.print("|   " +(i+1));
				System.out.print("|         " +idArr.get(i));
				System.out.print("|                   " +namaArr.get(i));
				System.out.print("|        " +jenisKelaminArr.get(i));
				System.out.print("|      " +jabatanArr.get(i));
				System.out.print("|      "+gajiArr.get(i));
				System.out.println("|");

			}
			
			int idx;
			System.out.print("Input angka list yang ingin diupdate [1.." +namaArr.size() + "]:");
			idx = scan.nextInt();
			scan.nextLine();
					
			String nama1=null, jenisKelamin1=null;
			String jabatan1=null;
			String id1 = "";
			int gaji1 = 0;
			
			do {
				System.out.print("Update Kode Karyawan: ");
				id1 = scan.nextLine();
			} while(!(id1.length()==7));
			
			do {
				System.out.print("Update nama karyawan [>= 3]: ");
				nama1 = scan.nextLine();
			} while(!(nama1.length()>=3)&&nama1.matches("^[a-zA-Z]*$"));
			
			do {
				System.out.print("Update jenis kelamin [Laki-laki] | Perempuan] (Case Sensitive): ");
				jenisKelamin1 = scan.nextLine();
			} while(!(jenisKelamin1.equals("Laki-laki")||jenisKelamin1.equals("Perempuan")));
		
			do {
				System.out.print("Update jabatan [Manager | Supervisor | Admin] (Case Sensitive): ");
				jabatan1 = scan.nextLine();
			} while(!jabatan1.equals("Manager")&&!jabatan1.equals("Supervisor")&&!jabatan1.equals("Admin"));
			
			do {
				System.out.print("Update gaji: ");
				gaji1 = scan.nextInt();
			} while(!(gaji1>=4000000));
		
			idArr.remove(idx-1);
			namaArr.remove(idx-1);
			jenisKelaminArr.remove(idx-1);
			jabatanArr.remove(idx-1);
			gajiArr.remove(idx-1);
			
			idArr.add(id1);
			namaArr.add(nama1);
			jenisKelaminArr.add(jenisKelamin1);
			jabatanArr.add(jabatan1);
			gajiArr.add(gaji1);
			
			System.out.println("Data karyawan berhasil di update!");
			
			break;
			}
			
		case 4:
			
			if(namaArr.size() == 0) {
				System.out.println("Tidak ada data karyawan!");
				menu();
			}
			System.out.println("|----|----------------|-------------------------|---------------|----------------|---------------|");
			System.out.println("|No  |Kode Karyawan   |Nama Karyawan            |Jenis Kelamin  |Jabatan         |Gaji Karyawan  |");
			System.out.println("|----|----------------|-------------------------|---------------|----------------|---------------|");
		for (int i = 0; i < namaArr.size(); i++) {	
			System.out.print("|   " +(i+1));
			System.out.print("|         " +idArr.get(i));
			System.out.print("|                   " +namaArr.get(i));
			System.out.print("|        " +jenisKelaminArr.get(i));
			System.out.print("|      " +jabatanArr.get(i));
			System.out.print("|      "+gajiArr.get(i));
			System.out.println("|");

			}
			
			int idx;
			System.out.print("Input angka list yang ingin didelete [1.." +namaArr.size() + "]:");
			idx = scan.nextInt();
			
			idArr.remove(idx-1);
			namaArr.remove(idx-1);
			jenisKelaminArr.remove(idx-1);
			jabatanArr.remove(idx-1);
			gajiArr.remove(idx-1);
			
			System.out.println("Data karyawan berhasil dihapus");
			
			break;
			}
			}
		}
		
		
	public static void main(String[] args) {
		new Main();
		// TODO Auto-generated method stub
	}
}
	